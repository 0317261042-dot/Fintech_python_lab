# hw2_promo_code.py

# 1. Nhập vào Họ Tên đầy đủ

full_name = input("Nhập vào Họ Tên đầy đủ: ").strip()


# 2. Nhập vào Năm sinh

birth_year = input("Nhập vào Năm sinh: ").strip()


# 3. Xử lý chuỗi để lấy Tên (từ cuối cùng)

# Tách chuỗi thành danh sách các từ

name_parts = full_name.split()


# Lấy từ cuối cùng trong danh sách làm Tên (nếu nhập trống sẽ mặc định là chuỗi rỗng)

first_name = name_parts[-1] if name_parts else ""


# Lấy tối đa 3 ký tự đầu của Tên và chuyển thành chữ in hoa

name_code = first_name[0:3].upper()


# Tạo mã ưu đãi bằng F-string theo định dạng [Tên]- [Năm sinh]-[VIP]

promo_code = f"{name_code}-{birth_year}-VIP"

# Hiển thị kết quả

print(f"Mã ưu đãi của bạn là: {promo_code}")